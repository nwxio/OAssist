# OAssist for Outline

Production-ready assistant service for Outline with RAG search and multi-provider LLM routing.

## Features

- Multi-provider chat routing with fallback: `ollama -> openai -> deepseek`
- Vector search over Outline documents using Qdrant
- Full-document access from Outline search (title-aware) for exact operations
- Full sync worker for continuous indexing
- API endpoint for chat answers with citations from Outline
- Text tools: summarize, rewrite, translate
- Browser chat UI at `/ui` with streaming responses, trace log, and sync control
- Built-in auth with SQLite users (`admin` / `user` roles)
- Provider health endpoint

## Roles

- `admin` role: admin panel access (sync + user/ACL management)
- `user` role: chat and assistant tools only (no admin sync/users/ACL access)

### ACL behavior

- `admin` username is treated as super-admin and always has full document access.
- All other users (including non-super-admin users with `admin` role) are restricted by ACL.
- ACL resolution order:
  - if user override list is not empty -> use user override list
  - else -> use global default list
- Parent document selection is expanded to include all descendants.
- RAG retrieval is strictly filtered by effective ACL before sources are sent to the model.

## Auth API

- `POST /auth/login`
- `POST /auth/logout`
- `GET /auth/me`
- `POST /auth/me/change-password`
- `GET /auth/users` (admin)
- `POST /auth/users` (admin)
- `PATCH /auth/users/{id}` (admin)
- `DELETE /auth/users/{id}` (admin)

## ACL API

- `GET /outline/tree` (filtered by effective ACL for current user)
- `GET /acl/global` (admin)
- `PUT /acl/global` (admin)
- `GET /acl/users/{id}` (admin)
- `PUT /acl/users/{id}` (admin)
- `GET /acl/me` (current user's effective ACL)

## Services

- `oassist-api` (FastAPI, port `8181`)
- `oassist-worker` (periodic Outline sync)
- `qdrant` (vector store, port `6333`)
- `ollama` (optional profile, port `11434`)

## Quick Start

1. Create config:

```bash
cp .env.example .env
```

2. Fill required values in `.env`:

- `OUTLINE_BASE_URL`
- `OUTLINE_API_TOKEN`
- `AUTH_BOOTSTRAP_ADMIN_USERNAME`
- `AUTH_BOOTSTRAP_ADMIN_PASSWORD`
- Optional keys: `OPENAI_API_KEY`, `DEEPSEEK_API_KEY`

Note: `OASSIST_ADMIN_TOKEN` is legacy and not required for new role-based auth.

3. Start services:

```bash
docker compose --profile ollama up -d --build
```

4. Pull Ollama models (if using local Ollama):

```bash
docker compose exec ollama ollama pull qwen2.5:14b
docker compose exec ollama ollama pull nomic-embed-text
```

5. Login and keep session cookie:

```bash
curl -c cookie.txt -X POST "http://localhost:8181/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin12345"}'
```

6. Start async sync and check progress:

```bash
curl -X POST "http://localhost:8181/sync/start" \
  -b cookie.txt

curl "http://localhost:8181/sync/status" \
  -b cookie.txt
```

Optional blocking sync:

```bash
curl -X POST "http://localhost:8181/sync/full" \
  -b cookie.txt
```

7. Ask a question:

```bash
curl -X POST "http://localhost:8181/chat" \
  -H "Content-Type: application/json" \
  -b cookie.txt \
  -d '{"question":"Как настроен SSO в нашей wiki?","provider":"auto","top_k":6}'

# conversational chat (with memory)
curl -X POST "http://localhost:8181/assistant/chat" \
  -H "Content-Type: application/json" \
  -d '{"message":"Привет, кто ты?","provider":"auto","use_knowledge":true,"top_k":6,"history":[]}'

# streaming chat (SSE)
curl -N -X POST "http://localhost:8181/assistant/chat/stream" \
  -H "Content-Type: application/json" \
  -d '{"message":"Как настроен OIDC?","provider":"auto","use_knowledge":true,"top_k":6,"history":[]}'

# summarize
curl -X POST "http://localhost:8181/tasks/summarize" \
  -H "Content-Type: application/json" \
  -d '{"text":"Long text...","provider":"auto"}'

# rewrite
curl -X POST "http://localhost:8181/tasks/rewrite" \
  -H "Content-Type: application/json" \
  -d '{"text":"Draft text...","style":"formal","provider":"auto"}'

# translate
curl -X POST "http://localhost:8181/tasks/translate" \
  -H "Content-Type: application/json" \
  -d '{"text":"Hello","target_language":"Ukrainian","provider":"auto"}'
```

## Health Checks

```bash
curl http://localhost:8181/health
curl http://localhost:8181/health/providers

# open browser UI
# http://localhost:8181/ui
```

## Notes

- `EMBEDDING_PROVIDER` supports `ollama` and `openai`
- `LLM_PROVIDER=auto` uses `LLM_FALLBACK_ORDER`
- Keep `OLLAMA` first for cost control and local privacy

from typing import Any

from qdrant_client import QdrantClient, models
from qdrant_client.http.exceptions import UnexpectedResponse

from app.config import Settings


class VectorStore:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = QdrantClient(url=settings.qdrant_url, api_key=settings.qdrant_api_key or None)

    def ensure_collection(self, vector_size: int) -> None:
        existing = {collection.name for collection in self.client.get_collections().collections}
        if self.settings.qdrant_collection in existing:
            return
        try:
            self.client.create_collection(
                collection_name=self.settings.qdrant_collection,
                vectors_config=models.VectorParams(size=vector_size, distance=models.Distance.COSINE),
            )
        except UnexpectedResponse as exc:
            if exc.status_code == 409:
                return
            raise

    def upsert(self, points: list[models.PointStruct]) -> None:
        if not points:
            return
        self.client.upsert(collection_name=self.settings.qdrant_collection, points=points)

    def delete_document(self, document_id: str) -> None:
        self.client.delete(
            collection_name=self.settings.qdrant_collection,
            points_selector=models.FilterSelector(
                filter=models.Filter(
                    must=[
                        models.FieldCondition(
                            key="document_id",
                            match=models.MatchValue(value=document_id),
                        )
                    ]
                )
            ),
        )

    def search(
        self,
        query_vector: list[float],
        limit: int,
        allowed_document_ids: set[str] | None = None,
    ) -> list[dict[str, Any]]:
        if allowed_document_ids is not None and not allowed_document_ids:
            return []

        query_filter = None
        if allowed_document_ids is not None:
            query_filter = models.Filter(
                should=[
                    models.FieldCondition(
                        key="document_id",
                        match=models.MatchValue(value=doc_id),
                    )
                    for doc_id in sorted(allowed_document_ids)
                ]
            )

        hits = self.client.search(
            collection_name=self.settings.qdrant_collection,
            query_vector=query_vector,
            limit=limit,
            with_payload=True,
            query_filter=query_filter,
        )
        rows: list[dict[str, Any]] = []
        for hit in hits:
            payload = hit.payload or {}
            rows.append(
                {
                    "score": float(hit.score),
                    "document_id": str(payload.get("document_id", "")),
                    "title": str(payload.get("title", "Untitled")),
                    "url": str(payload.get("url", "")),
                    "text": str(payload.get("text", "")),
                }
            )
        return rows

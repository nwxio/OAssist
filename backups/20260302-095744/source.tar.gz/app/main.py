import json
import re
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse, RedirectResponse, StreamingResponse

from app.acl import expand_document_ids_with_descendants, get_effective_allowed_document_ids, get_outline_tree, is_super_admin
from app.auth import (
    ROLE_ADMIN,
    AuthUser,
    authenticate_user,
    create_session,
    create_user,
    delete_user,
    get_acl_global_defaults,
    get_acl_user_overrides,
    get_user,
    get_user_by_session,
    get_chat_state_meta,
    init_auth_db,
    list_users,
    get_chat_state,
    save_chat_state,
    revoke_session,
    set_acl_global_defaults,
    set_acl_user_overrides,
    update_user,
)
from app.config import Settings, get_settings
from app.llm import LLMGateway
from app.rag import RAGService
from app.schemas import (
    AuthUserResponse,
    AssistantChatRequest,
    AssistantChatResponse,
    ChatRequest,
    ChatResponse,
    ChangePasswordRequest,
    CreateUserRequest,
    LoginRequest,
    LoginResponse,
    OllamaModelsResponse,
    ProvidersHealthResponse,
    RewriteRequest,
    SyncResponse,
    SyncStartResponse,
    SyncStatusResponse,
    TextTaskRequest,
    TextTaskResponse,
    TranslateRequest,
    UpdateUserRequest,
)
from app.sync import run_full_sync
from app.sync_jobs import sync_jobs

app = FastAPI(title="OAssist", version="1.1.0")
CHAT_UI_PATH = Path(__file__).resolve().parent / "static" / "chat.html"
CYRILLIC_RE = re.compile(r"[А-Яа-яЁё]")
LATIN_RE = re.compile(r"[A-Za-z]")


@app.on_event("startup")
def startup() -> None:
    settings = get_settings()
    init_auth_db(settings)


def _extract_session_token(request: Request) -> str:
    token = request.cookies.get("oassist_session") or ""
    if token:
        return token
    auth_header = request.headers.get("Authorization", "")
    if auth_header.lower().startswith("bearer "):
        return auth_header[7:].strip()
    return ""


def _public_user(user: AuthUser | dict[str, Any]) -> dict[str, Any]:
    if isinstance(user, dict):
        return {
            "id": int(user["id"]),
            "username": str(user["username"]),
            "role": str(user["role"]),
            "is_active": bool(user["is_active"]),
        }
    return {
        "id": int(user.id),
        "username": str(user.username),
        "role": str(user.role),
        "is_active": bool(user.is_active),
    }


def get_current_user(request: Request, settings: Settings = Depends(get_settings)) -> AuthUser:
    token = _extract_session_token(request)
    user = get_user_by_session(settings, token)
    if user is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    return user


def require_admin_role(current: AuthUser = Depends(get_current_user)) -> AuthUser:
    if current.role != ROLE_ADMIN:
        raise HTTPException(status_code=403, detail="Admin role required")
    return current


def _detect_language(text: str) -> str:
    return "ru" if CYRILLIC_RE.search(text) else "en"


def _filter_tree_nodes_by_allowed(nodes: list[dict[str, Any]], allowed_ids: set[str] | None) -> list[dict[str, Any]]:
    if allowed_ids is None:
        return nodes
    if not allowed_ids:
        return []

    filtered: list[dict[str, Any]] = []
    for node in nodes:
        if not isinstance(node, dict):
            continue
        doc_id = str(node.get("id") or "").strip()
        children = node.get("children")
        child_nodes = children if isinstance(children, list) else []
        kept_children = _filter_tree_nodes_by_allowed(child_nodes, allowed_ids)
        if doc_id in allowed_ids or kept_children:
            row = dict(node)
            row["children"] = kept_children
            filtered.append(row)
    return filtered


def _count_tree_nodes(nodes: list[dict[str, Any]]) -> int:
    total = 0
    for node in nodes:
        if not isinstance(node, dict):
            continue
        total += 1
        children = node.get("children")
        if isinstance(children, list) and children:
            total += _count_tree_nodes(children)
    return total


def _validate_acl_document_ids(settings: Settings, document_ids: set[str]) -> set[str]:
    if not document_ids:
        return set()
    try:
        tree = get_outline_tree(settings)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Failed to validate ACL documents: {exc}") from exc

    all_ids = {str(item).strip() for item in (tree.get("all_ids") or set()) if str(item).strip()}
    unknown = sorted([doc_id for doc_id in document_ids if doc_id not in all_ids])
    if unknown:
        preview = ", ".join(unknown[:12])
        suffix = "" if len(unknown) <= 12 else f" (+{len(unknown) - 12} more)"
        raise HTTPException(status_code=400, detail=f"Unknown document_ids: {preview}{suffix}")
    return document_ids


def _expand_acl_document_ids(settings: Settings, document_ids: set[str]) -> set[str]:
    if not document_ids:
        return set()
    try:
        tree = get_outline_tree(settings)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Failed to expand ACL documents: {exc}") from exc
    children_map = dict(tree.get("children_map") or {})
    return expand_document_ids_with_descendants(document_ids, children_map)


def _expanded_global_acl_scope(settings: Settings) -> set[str]:
    defaults = get_acl_global_defaults(settings)
    if not defaults:
        return set()
    valid = _validate_acl_document_ids(settings, defaults)
    return _expand_acl_document_ids(settings, valid)


def _language_from_custom_prompt(text: str) -> str | None:
    value = (text or "").strip().lower()
    if not value:
        return None

    ru_patterns = (
        "на русском",
        "русском языке",
        "только русский",
        "отвечай по-русски",
        "отвечай на русском",
        "пиши на русском",
        "reply in russian",
        "answer in russian",
    )
    en_patterns = (
        "in english",
        "answer in english",
        "reply in english",
        "на английском",
        "английском языке",
        "только английский",
    )

    if any(pattern in value for pattern in ru_patterns):
        return "ru"
    if any(pattern in value for pattern in en_patterns):
        return "en"
    return None


def _letter_counts(text: str) -> tuple[int, int]:
    cyr = len(CYRILLIC_RE.findall(text or ""))
    lat = len(LATIN_RE.findall(text or ""))
    return cyr, lat


def _needs_language_fix(answer: str, expected_lang: str) -> bool:
    cyr, lat = _letter_counts(answer)
    if expected_lang == "ru":
        return lat >= 24 and cyr < max(8, int(lat * 0.2))
    if expected_lang == "en":
        return cyr >= 24 and lat < max(8, int(cyr * 0.2))
    return False


def _enforce_answer_language(
    *,
    gateway: LLMGateway,
    answer: str,
    expected_lang: str,
    requested_provider: str,
) -> str:
    text = (answer or "").strip()
    if not text or not _needs_language_fix(text, expected_lang):
        return text

    if expected_lang == "ru":
        instruction = (
            "Перепиши ответ строго на русском языке. "
            "Сохрани структуру markdown, ссылки, кодовые блоки и технические термины без искажений."
        )
    else:
        instruction = (
            "Rewrite the answer strictly in English. "
            "Keep markdown structure, links, code blocks, and technical terms unchanged."
        )

    messages = [
        {"role": "system", "content": "You are a precise technical translator."},
        {"role": "user", "content": f"{instruction}\n\nANSWER:\n{text}"},
    ]

    try:
        fixed, _ = gateway.generate(messages=messages, requested_provider=requested_provider)
        fixed = (fixed or "").strip()
        if fixed:
            return fixed
    except Exception:
        pass
    return text


def _build_assistant_messages(
    payload: AssistantChatRequest,
    settings: Settings,
    user: AuthUser,
) -> tuple[list[dict[str, str]], list[dict[str, Any]], str]:
    custom_prompt = (payload.custom_prompt or "").strip()
    custom_prompt_lang = _language_from_custom_prompt(custom_prompt)

    forced_lang = (payload.chat_language or "").strip().lower()
    if forced_lang in {"ru", "en"}:
        lang = forced_lang
    else:
        lang = _detect_language(payload.message)

    if custom_prompt_lang in {"ru", "en"}:
        lang = custom_prompt_lang

    rag = RAGService(settings)
    allowed_document_ids = get_effective_allowed_document_ids(settings, user)

    context = ""
    sources: list[dict[str, Any]] = []
    full_docs: list[dict[str, Any]] = []
    if payload.use_knowledge:
        context, sources = rag.retrieve(
            question=payload.message,
            top_k=payload.top_k or settings.search_top_k,
            allowed_document_ids=allowed_document_ids,
        )
        full_docs = rag.retrieve_full_documents(
            question=payload.message,
            allowed_document_ids=allowed_document_ids,
        )

        known_ids = {str(item.get("document_id") or "") for item in sources}
        for item in full_docs:
            doc_id = str(item.get("document_id") or "")
            if not doc_id or doc_id in known_ids:
                continue
            known_ids.add(doc_id)
            sources.append(
                {
                    "document_id": doc_id,
                    "title": str(item.get("title") or "Untitled"),
                    "url": str(item.get("url") or ""),
                    "score": float(item.get("score") or 0.0),
                    "excerpt": str(item.get("text") or "")[:280],
                }
            )

    base_prompt = (
        "You are OAssist, an engineering knowledge-base assistant. "
        "Be concise and practical. "
        "If context is insufficient, state it explicitly. "
        "Do not hallucinate."
    )

    if lang == "ru":
        context_intro = (
            "Используй контекст Outline ниже для фактов и добавляй ссылки на источники, когда это уместно."
        )
    else:
        context_intro = "Use Outline context below for factual statements and cite sources when relevant."

    lang_hint = (payload.chat_language_hint or "").strip()
    if lang_hint:
        system_prompt = (
            f"{base_prompt} "
            "Always reply in the language of the first user message in this chat, "
            "unless the user explicitly asks to switch language. "
            f"First user message sample: {lang_hint[:280]}"
        )
    elif lang == "ru":
        system_prompt = (
            f"{base_prompt} "
            "Всегда отвечай на русском языке в рамках текущего диалога, "
            "если пользователь явно не попросил переключить язык."
        )
    else:
        system_prompt = (
            f"{base_prompt} "
            "Always answer in English for this chat unless the user explicitly asks to switch language."
        )

    if lang == "ru":
        language_guard = (
            "CRITICAL LANGUAGE RULE: Отвечай только на русском языке. "
            "Не переключайся на английский без явной просьбы пользователя."
        )
        output_language_prompt = (
            "OUTPUT FORMAT RULE: Финальный ответ должен быть полностью на русском языке, "
            "включая заголовки и пояснения. Допускаются только технические термины и названия как в оригинале."
        )
    else:
        language_guard = (
            "CRITICAL LANGUAGE RULE: Reply only in English. "
            "Do not switch to Russian unless the user explicitly asks."
        )
        output_language_prompt = (
            "OUTPUT FORMAT RULE: The final answer must be fully in English, including headings and explanations."
        )

    messages: list[dict[str, str]] = [
        {"role": "system", "content": language_guard},
        {"role": "system", "content": system_prompt},
        {"role": "system", "content": output_language_prompt},
    ]

    if custom_prompt:
        messages.append(
            {
                "role": "system",
                "content": (
                    "Apply the following user custom instructions with high priority in this chat. "
                    "These instructions override style/format defaults, while safety restrictions still apply:\n"
                    f"{custom_prompt[:4000]}"
                ),
            }
        )

    if context:
        messages.append(
            {
                "role": "system",
                "content": f"{context_intro}\n\nOutline context:\n{context}",
            }
        )

    if full_docs:
        blocks: list[str] = []
        for idx, item in enumerate(full_docs, start=1):
            blocks.append(
                f"[DOC {idx}] {item['title']}\nURL: {item['url']}\nCONTENT:\n{item['text']}"
            )
        messages.append(
            {
                "role": "system",
                "content": (
                    "Use full document access below when the user references document names or asks for exact commands. "
                    "Prefer full-document facts over short snippets when both exist.\n\n"
                    + "\n\n".join(blocks)
                ),
            }
        )

    for item in payload.history[-16:]:
        text = item.content.strip()
        if text:
            messages.append({"role": item.role, "content": text})

    messages.append({"role": "user", "content": payload.message.strip()})
    return messages, sources, lang


def _sse(event: str, data: dict[str, Any]) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/")
def root() -> RedirectResponse:
    return RedirectResponse(url="/ui", status_code=302)


@app.get("/ui")
def ui() -> FileResponse:
    return FileResponse(
        CHAT_UI_PATH,
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "Expires": "0",
        },
    )


@app.post("/auth/login", response_model=LoginResponse)
def auth_login(payload: LoginRequest, response: Response, settings: Settings = Depends(get_settings)):
    user = authenticate_user(settings, payload.username, payload.password)
    if user is None:
        raise HTTPException(status_code=401, detail="Invalid username or password")

    token = create_session(settings, user.id)
    max_age = settings.auth_session_ttl_hours * 3600
    response.set_cookie(
        key="oassist_session",
        value=token,
        httponly=True,
        secure=False,
        samesite="lax",
        max_age=max_age,
        path="/",
    )
    return {"token": token, "user": _public_user(user)}


@app.post("/auth/logout")
def auth_logout(request: Request, response: Response, settings: Settings = Depends(get_settings)):
    token = _extract_session_token(request)
    if token:
        revoke_session(settings, token)
    response.delete_cookie("oassist_session", path="/")
    return {"ok": True}


@app.get("/auth/me", response_model=AuthUserResponse)
def auth_me(current: AuthUser = Depends(get_current_user)):
    return _public_user(current)


@app.post("/auth/me/change-password")
def auth_change_password(
    payload: ChangePasswordRequest,
    settings: Settings = Depends(get_settings),
    current: AuthUser = Depends(get_current_user),
):
    auth_user = authenticate_user(settings, current.username, payload.current_password)
    if auth_user is None:
        raise HTTPException(status_code=400, detail="Current password is invalid")

    try:
        update_user(settings, current.id, password=payload.new_password)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"ok": True}


@app.get("/auth/users", dependencies=[Depends(require_admin_role)])
def auth_users(settings: Settings = Depends(get_settings)):
    return list_users(settings)


@app.post("/auth/users", dependencies=[Depends(require_admin_role)])
def auth_create_user(payload: CreateUserRequest, settings: Settings = Depends(get_settings)):
    try:
        return create_user(settings, payload.username, payload.password, payload.role)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.patch("/auth/users/{user_id}")
def auth_update_user(
    user_id: int,
    payload: UpdateUserRequest,
    settings: Settings = Depends(get_settings),
    current: AuthUser = Depends(require_admin_role),
):
    if payload.password is not None:
        try:
            target_user = get_user(settings, int(user_id))
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        target_role = str(target_user.get("role") or "").strip().lower()
        if target_role == ROLE_ADMIN and not is_super_admin(current):
            raise HTTPException(status_code=403, detail="Only super admin can change admin passwords")

    try:
        return update_user(
            settings,
            user_id,
            username=payload.username,
            password=payload.password,
            role=payload.role,
            is_active=payload.is_active,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.delete("/auth/users/{user_id}", dependencies=[Depends(require_admin_role)])
def auth_delete_user(user_id: int, settings: Settings = Depends(get_settings)):
    try:
        delete_user(settings, user_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"ok": True}


@app.get("/health/providers", response_model=ProvidersHealthResponse)
def provider_health(settings: Settings = Depends(get_settings), _user: AuthUser = Depends(get_current_user)):
    gateway = LLMGateway(settings)
    return gateway.provider_health()


@app.get("/models/ollama", response_model=OllamaModelsResponse)
def ollama_models(settings: Settings = Depends(get_settings), _user: AuthUser = Depends(get_current_user)):
    gateway = LLMGateway(settings)
    try:
        models = gateway.list_ollama_models()
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {"models": models, "default_model": settings.ollama_model}


@app.get("/outline/tree")
def outline_tree(settings: Settings = Depends(get_settings), user: AuthUser = Depends(get_current_user)):
    try:
        tree = get_outline_tree(settings)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    allowed_document_ids = get_effective_allowed_document_ids(settings, user)
    visible_nodes = _filter_tree_nodes_by_allowed(list(tree.get("nodes") or []), allowed_document_ids)
    visible_count = int(tree.get("count", 0)) if allowed_document_ids is None else _count_tree_nodes(visible_nodes)
    return {"nodes": visible_nodes, "count": visible_count}


@app.get("/acl/global", dependencies=[Depends(require_admin_role)])
def acl_global_get(settings: Settings = Depends(get_settings), _user: AuthUser = Depends(get_current_user)):
    return {"document_ids": sorted(get_acl_global_defaults(settings))}


@app.put("/acl/global", dependencies=[Depends(require_admin_role)])
def acl_global_put(
    payload: dict[str, Any],
    settings: Settings = Depends(get_settings),
    _user: AuthUser = Depends(get_current_user),
):
    raw_ids = payload.get("document_ids") if isinstance(payload, dict) else None
    if raw_ids is None:
        raw_ids = []
    if not isinstance(raw_ids, list):
        raise HTTPException(status_code=400, detail="document_ids must be an array")
    doc_ids = _validate_acl_document_ids(
        settings,
        {str(item).strip() for item in raw_ids if str(item).strip()},
    )
    expanded_doc_ids = _expand_acl_document_ids(settings, doc_ids)
    set_acl_global_defaults(settings, expanded_doc_ids)
    return {"ok": True, "document_ids": sorted(expanded_doc_ids)}


@app.get("/acl/users/{user_id}", dependencies=[Depends(require_admin_role)])
def acl_user_get(user_id: int, settings: Settings = Depends(get_settings), _user: AuthUser = Depends(get_current_user)):
    try:
        target_user = get_user(settings, int(user_id))
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    overrides = get_acl_user_overrides(settings, int(user_id))
    is_target_super_admin = str(target_user.get("username") or "").strip().lower() == "admin"
    if not is_target_super_admin:
        scope_ids = _expanded_global_acl_scope(settings)
        overrides = {doc_id for doc_id in overrides if doc_id in scope_ids}

    return {"user_id": int(user_id), "document_ids": sorted(overrides)}


@app.put("/acl/users/{user_id}", dependencies=[Depends(require_admin_role)])
def acl_user_put(
    user_id: int,
    payload: dict[str, Any],
    settings: Settings = Depends(get_settings),
    _user: AuthUser = Depends(get_current_user),
):
    raw_ids = payload.get("document_ids") if isinstance(payload, dict) else None
    if raw_ids is None:
        raw_ids = []
    if not isinstance(raw_ids, list):
        raise HTTPException(status_code=400, detail="document_ids must be an array")
    try:
        target_user = get_user(settings, int(user_id))
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    is_target_super_admin = str(target_user.get("username") or "").strip().lower() == "admin"
    if is_target_super_admin:
        raise HTTPException(status_code=400, detail="Super admin ACL cannot be changed")

    doc_ids = _validate_acl_document_ids(
        settings,
        {str(item).strip() for item in raw_ids if str(item).strip()},
    )
    expanded_doc_ids = _expand_acl_document_ids(settings, doc_ids)

    scope_ids = _expanded_global_acl_scope(settings)
    outside_scope = sorted(doc_id for doc_id in expanded_doc_ids if doc_id not in scope_ids)
    if outside_scope:
        preview = ", ".join(outside_scope[:12])
        suffix = "" if len(outside_scope) <= 12 else f" (+{len(outside_scope) - 12} more)"
        raise HTTPException(
            status_code=400,
            detail=f"ACL documents are outside default scope: {preview}{suffix}",
        )

    set_acl_user_overrides(settings, int(user_id), expanded_doc_ids)
    return {"ok": True, "user_id": int(user_id), "document_ids": sorted(expanded_doc_ids)}


@app.get("/acl/me")
def acl_me(settings: Settings = Depends(get_settings), user: AuthUser = Depends(get_current_user)):
    allowed_document_ids = get_effective_allowed_document_ids(settings, user)
    return {
        "is_super_admin": bool(is_super_admin(user)),
        "allowed_document_ids": None if allowed_document_ids is None else sorted(allowed_document_ids),
    }


@app.get("/chat/state")
def chat_state_get(settings: Settings = Depends(get_settings), user: AuthUser = Depends(get_current_user)):
    state = get_chat_state(settings, user.id)
    meta = get_chat_state_meta(settings, user.id)
    return {"state": state, "updated_at": meta.get("updated_at")}


@app.put("/chat/state")
def chat_state_put(
    payload: dict[str, Any],
    settings: Settings = Depends(get_settings),
    user: AuthUser = Depends(get_current_user),
):
    state = payload.get("state") if isinstance(payload, dict) else None
    if not isinstance(state, dict):
        raise HTTPException(status_code=400, detail="state must be an object")
    result = save_chat_state(settings, user.id, state)
    return {"ok": True, **result}


@app.get("/chat/state/meta")
def chat_state_meta(settings: Settings = Depends(get_settings), user: AuthUser = Depends(get_current_user)):
    return get_chat_state_meta(settings, user.id)


@app.post("/chat", response_model=ChatResponse)
def chat(payload: ChatRequest, settings: Settings = Depends(get_settings), user: AuthUser = Depends(get_current_user)):
    rag = RAGService(settings)
    try:
        allowed_document_ids = get_effective_allowed_document_ids(settings, user)
        data = rag.answer(
            question=payload.question,
            provider=payload.provider,
            top_k=payload.top_k or settings.search_top_k,
            allowed_document_ids=allowed_document_ids,
        )
        return data
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post("/assistant/chat", response_model=AssistantChatResponse)
def assistant_chat(
    payload: AssistantChatRequest,
    settings: Settings = Depends(get_settings),
    user: AuthUser = Depends(get_current_user),
):
    gateway = LLMGateway(settings)
    messages, sources, lang = _build_assistant_messages(payload, settings, user)
    try:
        output, provider = gateway.generate(
            messages=messages,
            requested_provider=payload.provider,
            requested_model=payload.model,
        )
        output = _enforce_answer_language(
            gateway=gateway,
            answer=output,
            expected_lang=lang,
            requested_provider=provider,
        )
        return {"provider": provider, "answer": output, "sources": sources}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post("/assistant/chat/stream")
def assistant_chat_stream(
    payload: AssistantChatRequest,
    settings: Settings = Depends(get_settings),
    user: AuthUser = Depends(get_current_user),
):
    gateway = LLMGateway(settings)

    def stream() -> Any:
        try:
            stream_lang = (payload.chat_language or "").strip().lower()
            if stream_lang not in {"ru", "en"}:
                hint = (payload.chat_language_hint or "").strip()
                stream_lang = _detect_language(hint or payload.message)
            yield _sse(
                "status",
                {
                    "stage": "prepare",
                    "message": "Ищу релевантные материалы..." if stream_lang == "ru" else "Collecting relevant context...",
                },
            )

            messages, sources, lang = _build_assistant_messages(payload, settings, user)
            if sources:
                yield _sse("sources", {"items": sources})

            yield _sse(
                "status",
                {
                    "stage": "generate",
                    "message": "Генерирую ответ..." if lang == "ru" else "Generating answer...",
                },
            )

            provider_used = "unknown"
            answer_parts: list[str] = []
            for event in gateway.stream_generate(
                messages=messages,
                requested_provider=payload.provider,
                requested_model=payload.model,
            ):
                kind = event.get("type")
                if kind == "provider":
                    provider_used = event.get("provider", "unknown")
                    yield _sse("provider", {"provider": provider_used})
                    continue
                if kind == "chunk":
                    chunk = event.get("content", "")
                    if chunk:
                        answer_parts.append(chunk)
                        yield _sse("chunk", {"text": chunk})

            yield _sse(
                "done",
                {
                    "provider": provider_used,
                    "answer": _enforce_answer_language(
                        gateway=gateway,
                        answer="".join(answer_parts).strip(),
                        expected_lang=lang,
                        requested_provider=provider_used if provider_used in {"ollama", "openai", "deepseek"} else payload.provider,
                    ),
                    "sources": sources,
                },
            )
        except Exception as exc:
            yield _sse("error", {"detail": str(exc)})

    headers = {
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no",
    }
    return StreamingResponse(stream(), media_type="text/event-stream", headers=headers)


@app.post("/sync/full", response_model=SyncResponse, dependencies=[Depends(require_admin_role)])
def sync_full(settings: Settings = Depends(get_settings)):
    if not settings.outline_api_token.strip():
        raise HTTPException(status_code=400, detail="OUTLINE_API_TOKEN is empty")
    if sync_jobs.is_running():
        raise HTTPException(status_code=409, detail="background sync is running")
    return run_full_sync(settings)


@app.post("/sync/start", response_model=SyncStartResponse, dependencies=[Depends(require_admin_role)])
def sync_start(settings: Settings = Depends(get_settings)):
    if not settings.outline_api_token.strip():
        raise HTTPException(status_code=400, detail="OUTLINE_API_TOKEN is empty")
    try:
        state = sync_jobs.start(settings)
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return {"job_id": state["job_id"], "status": state["status"]}


@app.get("/sync/status", response_model=SyncStatusResponse, dependencies=[Depends(require_admin_role)])
def sync_status():
    return sync_jobs.status()


@app.post("/tasks/summarize", response_model=TextTaskResponse)
def summarize(
    payload: TextTaskRequest,
    settings: Settings = Depends(get_settings),
    _user: AuthUser = Depends(get_current_user),
):
    gateway = LLMGateway(settings)
    messages = [
        {"role": "system", "content": "You summarize technical text into clear bullet points."},
        {
            "role": "user",
            "content": f"Summarize the following text in 5-8 concise bullets:\n\n{payload.text}",
        },
    ]
    try:
        output, provider = gateway.generate(messages=messages, requested_provider=payload.provider)
        return {"provider": provider, "output": output}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post("/tasks/rewrite", response_model=TextTaskResponse)
def rewrite(
    payload: RewriteRequest,
    settings: Settings = Depends(get_settings),
    _user: AuthUser = Depends(get_current_user),
):
    gateway = LLMGateway(settings)
    messages = [
        {"role": "system", "content": "You rewrite technical text while preserving meaning."},
        {
            "role": "user",
            "content": (
                f"Rewrite the text in this style: {payload.style}. "
                "Keep all important technical details.\n\n"
                f"Text:\n{payload.text}"
            ),
        },
    ]
    try:
        output, provider = gateway.generate(messages=messages, requested_provider=payload.provider)
        return {"provider": provider, "output": output}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post("/tasks/translate", response_model=TextTaskResponse)
def translate(
    payload: TranslateRequest,
    settings: Settings = Depends(get_settings),
    _user: AuthUser = Depends(get_current_user),
):
    gateway = LLMGateway(settings)
    messages = [
        {
            "role": "system",
            "content": "You are a precise technical translator and preserve original meaning.",
        },
        {
            "role": "user",
            "content": (
                f"Translate the text into {payload.target_language}. "
                "Keep technical names and code blocks intact.\n\n"
                f"Text:\n{payload.text}"
            ),
        },
    ]
    try:
        output, provider = gateway.generate(messages=messages, requested_provider=payload.provider)
        return {"provider": provider, "output": output}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

import hashlib
import uuid
from collections.abc import Callable
from time import monotonic
from typing import Any

from qdrant_client import models

from app.config import Settings
from app.embeddings import EmbeddingClient
from app.outline_client import OutlineClient
from app.vector_store import VectorStore


def chunk_text(text: str, chunk_size: int, chunk_overlap: int) -> list[str]:
    cleaned = "\n".join(part.strip() for part in text.splitlines() if part.strip())
    if not cleaned:
        return []
    chunks: list[str] = []
    start = 0
    step = max(1, chunk_size - chunk_overlap)
    while start < len(cleaned):
        end = min(len(cleaned), start + chunk_size)
        chunks.append(cleaned[start:end])
        if end == len(cleaned):
            break
        start += step
    return chunks


def build_document_url(base_url: str, doc: dict[str, Any]) -> str:
    url = str(doc.get("url") or "").strip()
    if url.startswith("http://") or url.startswith("https://"):
        return url
    if url.startswith("/"):
        return f"{base_url.rstrip('/')}{url}"
    doc_id = doc.get("id")
    return f"{base_url.rstrip('/')}/doc/{doc_id}"


def normalize_document(base_url: str, raw: dict[str, Any]) -> dict[str, str] | None:
    doc_id = str(raw.get("id") or "").strip()
    text = str(raw.get("text") or raw.get("content") or "").strip()
    if not doc_id or not text:
        return None
    return {
        "id": doc_id,
        "title": str(raw.get("title") or "Untitled"),
        "text": text,
        "url": build_document_url(base_url, raw),
    }


def run_full_sync(
    settings: Settings,
    progress_callback: Callable[[dict[str, int | float]], None] | None = None,
) -> dict[str, int | float]:
    if not settings.outline_api_token.strip():
        return {
            "indexed_documents": 0,
            "indexed_chunks": 0,
            "total_documents": 0,
            "processed_documents": 0,
            "failed_documents": 0,
            "duration_seconds": 0.0,
        }

    started = monotonic()
    outline = OutlineClient(settings)
    embeddings = EmbeddingClient(settings)
    store = VectorStore(settings)

    documents = list(outline.iter_documents())
    total_documents = len(documents)

    indexed_documents = 0
    indexed_chunks = 0
    processed_documents = 0
    failed_documents = 0
    collection_ready = False

    if progress_callback:
        progress_callback(
            {
                "total_documents": total_documents,
                "processed_documents": processed_documents,
                "indexed_documents": indexed_documents,
                "indexed_chunks": indexed_chunks,
                "failed_documents": failed_documents,
                "progress_percent": 0.0,
            }
        )

    for item in documents:
        doc_id = str(item.get("id") or "").strip()
        if not doc_id:
            processed_documents += 1
            continue
        try:
            info = outline.get_document(doc_id)
            merged = dict(item)
            merged.update(info)

            normalized = normalize_document(settings.outline_base_url, merged)
            if not normalized:
                processed_documents += 1
                continue

            chunks = chunk_text(normalized["text"], settings.chunk_size, settings.chunk_overlap)
            if not chunks:
                processed_documents += 1
                continue

            embedding_inputs = [f"{normalized['title']}\n\n{chunk}" for chunk in chunks]
            vectors = embeddings.embed_texts(embedding_inputs)
            if not vectors:
                processed_documents += 1
                continue

            if not collection_ready:
                store.ensure_collection(len(vectors[0]))
                collection_ready = True

            store.delete_document(normalized["id"])

            points: list[models.PointStruct] = []
            for index, (chunk, vector) in enumerate(zip(chunks, vectors)):
                digest = hashlib.sha1(chunk.encode("utf-8")).hexdigest()
                point_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{normalized['id']}:{index}:{digest}"))
                points.append(
                    models.PointStruct(
                        id=point_id,
                        vector=vector,
                        payload={
                            "document_id": normalized["id"],
                            "title": normalized["title"],
                            "url": normalized["url"],
                            "chunk_index": index,
                            "text": chunk,
                        },
                    )
                )

            store.upsert(points)
            indexed_documents += 1
            indexed_chunks += len(points)
        except Exception:
            failed_documents += 1
        finally:
            processed_documents += 1
            if progress_callback:
                percent = (processed_documents / total_documents * 100.0) if total_documents else 100.0
                progress_callback(
                    {
                        "total_documents": total_documents,
                        "processed_documents": processed_documents,
                        "indexed_documents": indexed_documents,
                        "indexed_chunks": indexed_chunks,
                        "failed_documents": failed_documents,
                        "progress_percent": round(percent, 2),
                    }
                )

    return {
        "indexed_documents": indexed_documents,
        "indexed_chunks": indexed_chunks,
        "total_documents": total_documents,
        "processed_documents": processed_documents,
        "failed_documents": failed_documents,
        "duration_seconds": round(monotonic() - started, 2),
    }

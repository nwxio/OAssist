from __future__ import annotations

import json
import hashlib
import hmac
import secrets
import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from app.config import Settings


ROLE_ADMIN = "admin"
ROLE_USER = "user"
VALID_ROLES = {ROLE_ADMIN, ROLE_USER}


@dataclass
class AuthUser:
    id: int
    username: str
    role: str
    is_active: bool


def _utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def _utc_now_precise() -> str:
    return datetime.now(UTC).isoformat(timespec="microseconds")


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _hash_password(password: str, salt_hex: str) -> str:
    salt = bytes.fromhex(salt_hex)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 310_000)
    return digest.hex()


def _new_salt() -> str:
    return secrets.token_bytes(16).hex()


def _connect(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_auth_db(settings: Settings) -> None:
    path = Path(settings.auth_db_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with _connect(settings.auth_db_path) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              username TEXT NOT NULL UNIQUE,
              password_hash TEXT NOT NULL,
              salt TEXT NOT NULL,
              role TEXT NOT NULL,
              is_active INTEGER NOT NULL DEFAULT 1,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS sessions (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              token_hash TEXT NOT NULL UNIQUE,
              user_id INTEGER NOT NULL,
              created_at TEXT NOT NULL,
              expires_at TEXT NOT NULL,
              last_seen_at TEXT NOT NULL,
              FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS chat_states (
              user_id INTEGER PRIMARY KEY,
              state_json TEXT NOT NULL,
              updated_at TEXT NOT NULL,
              FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS acl_global_defaults (
              document_id TEXT PRIMARY KEY,
              updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS acl_user_overrides (
              user_id INTEGER NOT NULL,
              document_id TEXT NOT NULL,
              updated_at TEXT NOT NULL,
              PRIMARY KEY(user_id, document_id),
              FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_acl_user_overrides_user ON acl_user_overrides(user_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id)")
        conn.commit()

    _bootstrap_default_admin(settings)


def _bootstrap_default_admin(settings: Settings) -> None:
    username = settings.auth_bootstrap_admin_username.strip()
    password = settings.auth_bootstrap_admin_password.strip()
    if not username or not password:
        return

    with _connect(settings.auth_db_path) as conn:
        row = conn.execute("SELECT id FROM users LIMIT 1").fetchone()
        if row:
            return
    create_user(settings, username=username, password=password, role=ROLE_ADMIN)


def _row_to_user(row: sqlite3.Row | None) -> AuthUser | None:
    if row is None:
        return None
    return AuthUser(
        id=int(row["id"]),
        username=str(row["username"]),
        role=str(row["role"]),
        is_active=bool(int(row["is_active"])),
    )


def authenticate_user(settings: Settings, username: str, password: str) -> AuthUser | None:
    uname = username.strip()
    if not uname or not password:
        return None

    with _connect(settings.auth_db_path) as conn:
        row = conn.execute(
            "SELECT id, username, role, is_active, password_hash, salt FROM users WHERE lower(username)=lower(?)",
            (uname,),
        ).fetchone()
        if row is None:
            return None
        if not bool(int(row["is_active"])):
            return None

        expected = str(row["password_hash"])
        got = _hash_password(password, str(row["salt"]))
        if not hmac.compare_digest(expected, got):
            return None
        return _row_to_user(row)


def create_session(settings: Settings, user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    now = datetime.now(UTC)
    expires = now + timedelta(hours=settings.auth_session_ttl_hours)

    with _connect(settings.auth_db_path) as conn:
        conn.execute(
            "INSERT INTO sessions (token_hash, user_id, created_at, expires_at, last_seen_at) VALUES (?, ?, ?, ?, ?)",
            (
                _token_hash(token),
                int(user_id),
                now.isoformat(timespec="seconds"),
                expires.isoformat(timespec="seconds"),
                now.isoformat(timespec="seconds"),
            ),
        )
        conn.execute("DELETE FROM sessions WHERE expires_at < ?", (_utc_now(),))
        conn.commit()
    return token


def revoke_session(settings: Settings, token: str) -> None:
    if not token:
        return
    with _connect(settings.auth_db_path) as conn:
        conn.execute("DELETE FROM sessions WHERE token_hash=?", (_token_hash(token),))
        conn.commit()


def get_user_by_session(settings: Settings, token: str) -> AuthUser | None:
    if not token:
        return None

    with _connect(settings.auth_db_path) as conn:
        row = conn.execute(
            """
            SELECT u.id, u.username, u.role, u.is_active, s.id AS session_id
            FROM sessions s
            JOIN users u ON u.id = s.user_id
            WHERE s.token_hash = ? AND s.expires_at > ?
            """,
            (_token_hash(token), _utc_now()),
        ).fetchone()
        user = _row_to_user(row)
        if user is None or not user.is_active:
            return None

        conn.execute("UPDATE sessions SET last_seen_at=? WHERE id=?", (_utc_now(), int(row["session_id"])))
        conn.commit()
        return user


def list_users(settings: Settings) -> list[dict[str, Any]]:
    with _connect(settings.auth_db_path) as conn:
        rows = conn.execute(
            "SELECT id, username, role, is_active, created_at, updated_at FROM users ORDER BY username"
        ).fetchall()
    return [
        {
            "id": int(row["id"]),
            "username": str(row["username"]),
            "role": str(row["role"]),
            "is_active": bool(int(row["is_active"])),
            "created_at": str(row["created_at"]),
            "updated_at": str(row["updated_at"]),
        }
        for row in rows
    ]


def create_user(settings: Settings, username: str, password: str, role: str) -> dict[str, Any]:
    uname = username.strip()
    pwd = password.strip()
    role_name = role.strip().lower()
    if not uname:
        raise ValueError("username is required")
    if len(pwd) < 8:
        raise ValueError("password must be at least 8 characters")
    if role_name not in VALID_ROLES:
        raise ValueError("invalid role")

    salt = _new_salt()
    now = _utc_now()
    with _connect(settings.auth_db_path) as conn:
        try:
            cur = conn.execute(
                """
                INSERT INTO users (username, password_hash, salt, role, is_active, created_at, updated_at)
                VALUES (?, ?, ?, ?, 1, ?, ?)
                """,
                (uname, _hash_password(pwd, salt), salt, role_name, now, now),
            )
        except sqlite3.IntegrityError as exc:
            raise ValueError("username already exists") from exc
        conn.commit()
        user_id = int(cur.lastrowid)

    return get_user(settings, user_id)


def get_user(settings: Settings, user_id: int) -> dict[str, Any]:
    with _connect(settings.auth_db_path) as conn:
        row = conn.execute(
            "SELECT id, username, role, is_active, created_at, updated_at FROM users WHERE id=?",
            (int(user_id),),
        ).fetchone()
    if row is None:
        raise ValueError("user not found")
    return {
        "id": int(row["id"]),
        "username": str(row["username"]),
        "role": str(row["role"]),
        "is_active": bool(int(row["is_active"])),
        "created_at": str(row["created_at"]),
        "updated_at": str(row["updated_at"]),
    }


def _count_active_admins(settings: Settings) -> int:
    with _connect(settings.auth_db_path) as conn:
        row = conn.execute("SELECT COUNT(*) AS c FROM users WHERE role=? AND is_active=1", (ROLE_ADMIN,)).fetchone()
    return int(row["c"]) if row else 0


def update_user(
    settings: Settings,
    user_id: int,
    *,
    username: str | None = None,
    password: str | None = None,
    role: str | None = None,
    is_active: bool | None = None,
) -> dict[str, Any]:
    user = get_user(settings, user_id)
    updates: dict[str, Any] = {}

    if username is not None:
        cleaned = username.strip()
        if not cleaned:
            raise ValueError("username is required")
        updates["username"] = cleaned

    if role is not None:
        role_name = role.strip().lower()
        if role_name not in VALID_ROLES:
            raise ValueError("invalid role")
        if user["role"] == ROLE_ADMIN and role_name != ROLE_ADMIN and _count_active_admins(settings) <= 1:
            raise ValueError("cannot demote last active admin")
        updates["role"] = role_name

    if is_active is not None:
        active = bool(is_active)
        if user["role"] == ROLE_ADMIN and not active and _count_active_admins(settings) <= 1:
            raise ValueError("cannot deactivate last active admin")
        updates["is_active"] = 1 if active else 0

    password_hash = None
    salt = None
    if password is not None:
        pwd = password.strip()
        if len(pwd) < 8:
            raise ValueError("password must be at least 8 characters")
        salt = _new_salt()
        password_hash = _hash_password(pwd, salt)

    if not updates and password_hash is None:
        return user

    updates["updated_at"] = _utc_now()
    parts = [f"{key}=?" for key in updates.keys()]
    params = list(updates.values())
    if password_hash is not None and salt is not None:
        parts.extend(["password_hash=?", "salt=?"])
        params.extend([password_hash, salt])

    params.append(int(user_id))

    with _connect(settings.auth_db_path) as conn:
        try:
            conn.execute(f"UPDATE users SET {', '.join(parts)} WHERE id=?", params)
            conn.commit()
        except sqlite3.IntegrityError as exc:
            raise ValueError("username already exists") from exc

    return get_user(settings, user_id)


def delete_user(settings: Settings, user_id: int) -> None:
    user = get_user(settings, user_id)
    if user["role"] == ROLE_ADMIN and user["is_active"] and _count_active_admins(settings) <= 1:
        raise ValueError("cannot delete last active admin")

    with _connect(settings.auth_db_path) as conn:
        cur = conn.execute("DELETE FROM users WHERE id=?", (int(user_id),))
        conn.commit()
        if cur.rowcount == 0:
            raise ValueError("user not found")


def _parse_ts(raw: Any) -> datetime | None:
    if raw is None:
        return None
    text = str(raw).strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = f"{text[:-1]}+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _state_ts(state: dict[str, Any] | None, fallback: Any = None) -> datetime | None:
    if isinstance(state, dict):
        parsed = _parse_ts(state.get("_state_updated_at"))
        if parsed is not None:
            return parsed
    return _parse_ts(fallback)


def get_chat_state(settings: Settings, user_id: int) -> dict[str, Any] | None:
    with _connect(settings.auth_db_path) as conn:
        row = conn.execute("SELECT state_json FROM chat_states WHERE user_id=?", (int(user_id),)).fetchone()
    if row is None:
        return None
    raw = str(row["state_json"])
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def get_chat_state_meta(settings: Settings, user_id: int) -> dict[str, Any]:
    with _connect(settings.auth_db_path) as conn:
        row = conn.execute(
            "SELECT updated_at FROM chat_states WHERE user_id=?",
            (int(user_id),),
        ).fetchone()
    return {"updated_at": str(row["updated_at"]) if row else None}


def save_chat_state(settings: Settings, user_id: int, state: dict[str, Any]) -> dict[str, Any]:
    incoming = dict(state)
    incoming["_state_updated_at"] = str(incoming.get("_state_updated_at") or _utc_now_precise())

    with _connect(settings.auth_db_path) as conn:
        row = conn.execute(
            "SELECT state_json, updated_at FROM chat_states WHERE user_id=?",
            (int(user_id),),
        ).fetchone()

        if row is not None:
            existing_state: dict[str, Any] | None = None
            try:
                parsed = json.loads(str(row["state_json"]))
                if isinstance(parsed, dict):
                    existing_state = parsed
            except Exception:
                existing_state = None

            incoming_base_ts = _parse_ts(incoming.get("_state_base_updated_at"))
            server_row_ts = _parse_ts(row["updated_at"])
            if incoming_base_ts is not None and server_row_ts is not None and incoming_base_ts != server_row_ts:
                return {"updated_at": str(row["updated_at"]), "applied": False}

            incoming_ts = _state_ts(incoming)
            existing_ts = _state_ts(existing_state, fallback=row["updated_at"])
            if incoming_ts is not None and existing_ts is not None and incoming_ts < existing_ts:
                return {"updated_at": str(row["updated_at"]), "applied": False}

        server_updated_at = _utc_now_precise()
        payload = json.dumps(incoming, ensure_ascii=False)
        conn.execute(
            """
            INSERT INTO chat_states (user_id, state_json, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
              state_json=excluded.state_json,
              updated_at=excluded.updated_at
            """,
            (int(user_id), payload, server_updated_at),
        )
        conn.commit()
    return {"updated_at": server_updated_at, "applied": True}


def get_acl_global_defaults(settings: Settings) -> set[str]:
    with _connect(settings.auth_db_path) as conn:
        rows = conn.execute("SELECT document_id FROM acl_global_defaults").fetchall()
    return {str(row["document_id"]).strip() for row in rows if str(row["document_id"]).strip()}


def set_acl_global_defaults(settings: Settings, document_ids: set[str]) -> None:
    now = _utc_now()
    clean_ids = sorted({str(doc_id).strip() for doc_id in document_ids if str(doc_id).strip()})
    with _connect(settings.auth_db_path) as conn:
        conn.execute("DELETE FROM acl_global_defaults")
        if clean_ids:
            conn.executemany(
                "INSERT INTO acl_global_defaults (document_id, updated_at) VALUES (?, ?)",
                [(doc_id, now) for doc_id in clean_ids],
            )
        conn.commit()


def get_acl_user_overrides(settings: Settings, user_id: int) -> set[str]:
    with _connect(settings.auth_db_path) as conn:
        rows = conn.execute(
            "SELECT document_id FROM acl_user_overrides WHERE user_id=?",
            (int(user_id),),
        ).fetchall()
    return {str(row["document_id"]).strip() for row in rows if str(row["document_id"]).strip()}


def set_acl_user_overrides(settings: Settings, user_id: int, document_ids: set[str]) -> None:
    now = _utc_now()
    clean_ids = sorted({str(doc_id).strip() for doc_id in document_ids if str(doc_id).strip()})
    with _connect(settings.auth_db_path) as conn:
        conn.execute("DELETE FROM acl_user_overrides WHERE user_id=?", (int(user_id),))
        if clean_ids:
            conn.executemany(
                "INSERT INTO acl_user_overrides (user_id, document_id, updated_at) VALUES (?, ?, ?)",
                [(int(user_id), doc_id, now) for doc_id in clean_ids],
            )
        conn.commit()

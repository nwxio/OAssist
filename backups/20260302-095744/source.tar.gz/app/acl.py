from __future__ import annotations

from collections import defaultdict, deque
from typing import Any

from app.auth import AuthUser, get_acl_global_defaults, get_acl_user_overrides
from app.config import Settings
from app.outline_client import OutlineClient


SUPER_ADMIN_USERNAME = "admin"


def is_super_admin(user: AuthUser) -> bool:
    return str(user.username).strip().lower() == SUPER_ADMIN_USERNAME


def _normalize_doc_item(item: dict[str, Any], base_url: str) -> dict[str, Any] | None:
    doc_id = str(item.get("id") or "").strip()
    if not doc_id:
        return None
    title = str(item.get("title") or "Untitled").strip() or "Untitled"
    parent_id = str(item.get("parentDocumentId") or "").strip() or None
    url = str(item.get("url") or "").strip()
    if url.startswith("/"):
        url = f"{base_url.rstrip('/')}{url}"
    return {
        "id": doc_id,
        "title": title,
        "url": url,
        "parentDocumentId": parent_id,
        "children": [],
    }


def get_outline_tree(settings: Settings) -> dict[str, Any]:
    client = OutlineClient(settings)
    docs_by_id: dict[str, dict[str, Any]] = {}
    children_map: dict[str, list[str]] = defaultdict(list)
    parent_by_id: dict[str, str | None] = {}

    for raw in client.iter_documents():
        node = _normalize_doc_item(raw, settings.outline_base_url)
        if not node:
            continue
        doc_id = str(node["id"])
        docs_by_id[doc_id] = node
        parent_id = node.get("parentDocumentId")
        parent_by_id[doc_id] = parent_id
        if parent_id:
            children_map[parent_id].append(doc_id)

    roots: list[dict[str, Any]] = []
    for doc_id, node in docs_by_id.items():
        parent_id = parent_by_id.get(doc_id)
        if parent_id and parent_id in docs_by_id:
            docs_by_id[parent_id]["children"].append(node)
        else:
            roots.append(node)

    def sort_nodes(nodes: list[dict[str, Any]]) -> None:
        nodes.sort(key=lambda row: str(row.get("title") or "").lower())
        for row in nodes:
            kids = row.get("children")
            if isinstance(kids, list) and kids:
                sort_nodes(kids)

    sort_nodes(roots)
    return {
        "nodes": roots,
        "count": len(docs_by_id),
        "all_ids": set(docs_by_id.keys()),
        "children_map": {key: list(values) for key, values in children_map.items()},
    }


def _expand_with_descendants(selected_ids: set[str], children_map: dict[str, list[str]]) -> set[str]:
    expanded: set[str] = set()
    queue: deque[str] = deque(selected_ids)
    while queue:
        current = queue.popleft()
        if current in expanded:
            continue
        expanded.add(current)
        for child_id in children_map.get(current, []):
            if child_id not in expanded:
                queue.append(child_id)
    return expanded


def expand_document_ids_with_descendants(selected_ids: set[str], children_map: dict[str, list[str]]) -> set[str]:
    return _expand_with_descendants(selected_ids, children_map)


def get_effective_allowed_document_ids(settings: Settings, user: AuthUser) -> set[str] | None:
    if is_super_admin(user):
        return None

    global_defaults = get_acl_global_defaults(settings)
    user_overrides = get_acl_user_overrides(settings, user.id)

    if not global_defaults:
        return set()

    try:
        tree = get_outline_tree(settings)
        all_ids: set[str] = set(tree.get("all_ids") or set())
        children_map: dict[str, list[str]] = dict(tree.get("children_map") or {})

        defaults_known = {doc_id for doc_id in global_defaults if doc_id in all_ids}
        defaults_expanded = _expand_with_descendants(defaults_known, children_map)
        if not defaults_expanded:
            return set()

        if not user_overrides:
            return defaults_expanded

        overrides_known = {doc_id for doc_id in user_overrides if doc_id in all_ids}
        overrides_expanded = _expand_with_descendants(overrides_known, children_map)
        return defaults_expanded & overrides_expanded
    except Exception:
        # secure fallback: global defaults are an upper bound for everyone except super admin
        if not user_overrides:
            return set(global_defaults)
        return set(global_defaults) & set(user_overrides)
